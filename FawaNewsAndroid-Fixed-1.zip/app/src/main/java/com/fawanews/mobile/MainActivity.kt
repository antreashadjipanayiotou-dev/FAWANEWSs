package com.fawanews.mobile

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.CookieManager
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.webkit.WebSettings
import android.net.http.SslError

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var progress: ProgressBar
    private lateinit var errorPanel: LinearLayout
    private lateinit var errorText: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var pageReady = false
    private var pageLoadTimedOut = false

    private val loadTimeout = Runnable {
        if (!pageReady) showError("Η σελίδα δεν φόρτωσε εγκαίρως. Έλεγξε τη σύνδεσή σου και πάτησε Δοκιμή ξανά.")
    }

    // Use the website's own schedule control, without reloading the video page.
    private val scheduleRefresh = object : Runnable {
        override fun run() {
            if (pageReady && ::webView.isInitialized) {
                val js = """
                    (function() {
                      const wanted = 'press to refresh the schedule';
                      const candidates = Array.from(document.querySelectorAll(
                        'button, a, [role="button"], input[type="button"], input[type="submit"]'
                      ));
                      const el = candidates.find(e => {
                        const text = ((e.innerText || e.value || e.getAttribute('aria-label') || '') + '')
                          .replace(/\\s+/g, ' ').trim().toLowerCase();
                        if (!text || !text.includes(wanted)) return false;
                        const r = e.getBoundingClientRect();
                        const s = window.getComputedStyle(e);
                        return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none';
                      });
                      if (el) el.click();
                    })();
                """.trimIndent()
                webView.evaluateJavascript(js, null)
            }
            handler.postDelayed(this, 60_000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR

        val root = FrameLayout(this).apply { setBackgroundColor(Color.WHITE) }
        webView = WebView(this).apply { setBackgroundColor(Color.WHITE) }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }

        errorPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            setBackgroundColor(Color.WHITE)
            visibility = View.GONE
        }
        val heading = TextView(this).apply {
            text = "Δεν ήταν δυνατή η φόρτωση του FawaNews"
            textSize = 19f
            setTextColor(Color.BLACK)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        errorText = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 20)
        }
        val retry = Button(this).apply {
            text = "Δοκιμή ξανά"
            setOnClickListener { hideError(); loadHome() }
        }
        errorPanel.addView(heading)
        errorPanel.addView(errorText)
        errorPanel.addView(retry)

        val content = FrameLayout(this)
        content.addView(webView, FrameLayout.LayoutParams(-1, -1))
        content.addView(progress, FrameLayout.LayoutParams(-1, 6, Gravity.TOP))
        content.addView(errorPanel, FrameLayout.LayoutParams(-1, -1))
        root.addView(content)
        setContentView(root)

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, true)
        }
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadsImagesAutomatically = true
            useWideViewPort = true
            loadWithOverviewMode = true
            mediaPlaybackRequiresUserGesture = false
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(false)
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            cacheMode = WebSettings.LOAD_DEFAULT
            // Remove Android WebView markers that some sites reject, while retaining Chrome's engine UA.
            userAgentString = userAgentString.replace("; wv", "").replace("Version/4.0 ", "")
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }
        }
        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                pageReady = false
                pageLoadTimedOut = false
                hideError()
                handler.removeCallbacks(loadTimeout)
                handler.postDelayed(loadTimeout, 30_000L)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                pageReady = true
                pageLoadTimedOut = false
                handler.removeCallbacks(loadTimeout)
                hideError()
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true) {
                    handler.removeCallbacks(loadTimeout)
                    showError("Σφάλμα σύνδεσης (${error?.errorCode ?: "άγνωστο"}). Έλεγξε το internet και δοκίμασε ξανά.")
                }
            }

            override fun onReceivedHttpError(view: WebView?, request: WebResourceRequest?, errorResponse: android.webkit.WebResourceResponse?) {
                super.onReceivedHttpError(view, request, errorResponse)
                if (request?.isForMainFrame == true) {
                    handler.removeCallbacks(loadTimeout)
                    showError("Ο ιστότοπος επέστρεψε σφάλμα HTTP ${errorResponse?.statusCode ?: ""}. Δοκίμασε ξανά αργότερα.")
                }
            }

            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                handler?.cancel()
                showError("Δεν ήταν δυνατή η ασφαλής σύνδεση με το FawaNews. Έλεγξε ημερομηνία και ώρα στη συσκευή σου.")
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = false
        }

        if (savedInstanceState == null) loadHome()
        else {
            val restored = webView.restoreState(savedInstanceState)
            if (restored == null) loadHome()
        }
    }

    private fun loadHome() {
        pageReady = false
        handler.removeCallbacks(loadTimeout)
        handler.postDelayed(loadTimeout, 30_000L)
        webView.loadUrl("https://fawanews.sc/")
    }

    private fun showError(message: String) {
        errorText.text = message
        errorPanel.visibility = View.VISIBLE
        progress.visibility = View.GONE
    }

    private fun hideError() {
        if (::errorPanel.isInitialized) errorPanel.visibility = View.GONE
    }

    override fun onResume() {
        super.onResume()
        if (::webView.isInitialized) webView.onResume()
        handler.removeCallbacks(scheduleRefresh)
        handler.postDelayed(scheduleRefresh, 60_000L)
    }

    override fun onPause() {
        handler.removeCallbacks(scheduleRefresh)
        if (::webView.isInitialized) webView.onPause()
        super.onPause()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        if (::webView.isInitialized) webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }

    override fun onDestroy() {
        handler.removeCallbacks(scheduleRefresh)
        handler.removeCallbacks(loadTimeout)
        if (::webView.isInitialized) {
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }
}
