# FawaNews Android

Android WebView app for **https://fawanews.sc/**. It attempts to click the site's visible
"Press to Refresh The Schedule (GMT+1)" control every 60 seconds instead of reloading the page.

## Included
- Android app project in Kotlin.
- WebView with JavaScript, DOM storage, and cookies enabled.
- Foreground-only 60-second timer.
- GitHub Actions workflow that builds a debug APK and uploads it as an artifact.

## Important limitation
The screenshot shows the schedule-refresh control but does not reveal how the website implements it.
This app clicks that control every 60 seconds. If the control updates the schedule asynchronously,
the video should remain undisturbed. If the site's own control reloads the whole page, playback may
still stop. This needs testing on the live site; the app cannot guarantee behavior the site does
not expose.

The timer pauses when the app is in the background and resumes when it returns.

## Build using GitHub
1. Extract this ZIP.
2. Create a GitHub repository named `FawaNewsAndroid`.
3. Upload the contents to the repository's `main` branch. Include the hidden `.github` folder.
4. Open **Actions**.
5. Select **Build FawaNews Android APK** and press **Run workflow**. Pushes to `main` also trigger it.
6. Open the completed run and download **FawaNews-Android-APK**.
7. Extract that artifact ZIP and install `app-debug.apk` on your Android phone.

## Configuration
- Application ID: `com.fawanews.mobile`
- Minimum Android: 6.0 (API 23)
- Java: 17; Gradle: 8.9; Android Gradle Plugin: 8.7.3
